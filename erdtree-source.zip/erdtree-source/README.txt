erdtree source: everything behind erdtree.zip, for anyone who wants to read, change or rebuild it.

  source/   the engine (v0.5) for op1r and the Hundekraft Workshop: C source, generated tables and art, the preset
            generator, the host test harness. source/README.md has the build and test steps.
  opus/     the Opus 2 port: the plugin folder sammi.erdtree/ for the Opus plugin kit, its art generator, and the PC
            tests and media scripts. opus/README.md has the build and test steps.
  release/  the built files: erdtree.knl (v0.5) with its SHA-256, older/erdtree-v0.4.knl, opus/erdtree.opmod with its
            SHA-256, the preset pack, the changelog.
  social/   the Reddit and Discord announcement drafts.

GPL-3.0-or-later with the OP-1 firmware permission (source/LICENSE, source/NOTICE).
